package com.jnec.techfest.swayambhu;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;



public class Floatingmenu extends AppCompatActivity {

    String arrayName[] = { "Facebook",
            "Instagram",
            "Twitter",
            "Windows",
            "Website"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_floatingmenu);


    }
    }

