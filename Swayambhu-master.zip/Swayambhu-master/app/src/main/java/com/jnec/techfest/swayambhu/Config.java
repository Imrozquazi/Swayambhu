package com.jnec.techfest.swayambhu;

/**
 * Created by Ashay on 18-03-2018.
 */

public class Config {
    public static final String EMAIL ="jnec.swayambhu18@gmail.com";
    public static final String PASSWORD ="Techfest2018";
}

