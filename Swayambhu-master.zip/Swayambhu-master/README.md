  JNEC Swayambhu - Android App
  
 Jnec Swayambhu is android application that is used for event description 
 and booking tickets in our annual technical fest. Swayambhu is annual
 technical fest of Jawaharlal Nehru Engineering College. It has events
 different events for different departments. 
 
 It had more than 500+ downloads in just 8 days. 
 
 It provides features such as,
 
    * Interactive UI.
    * Sign-up for new user.
    * Detailed Event Description.
    * Notifies the user on event registration through SMS and Email.
